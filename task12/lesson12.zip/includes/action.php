<?php
include "header.php";
include('db.php');
include "nav.php";


$search = $_POST['search'];
$button = $_POST['button'];



if(isset($button)){

    $sql_search = "SELECT * FROM posts WHERE title LIKE '%{$search}%'";
    $search_q = mysqli_query($connection,$sql_search);
    $count= mysqli_num_rows($search_q);

    if($count == 0){
        echo "<h3>Nothing</h3>";
    }else{
        foreach ($search_q as $title){

            echo "<h3><a href='#'>{$title['title']}</a></h3>";

        }
    }

}


include "footer.php";
